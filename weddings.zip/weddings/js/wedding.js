jQuery(document).ready(function($){

    
    
}
);