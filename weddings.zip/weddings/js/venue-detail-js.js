$('#myCarousel').carousel({
    interval: 5000
  })
  
  