
<?php

// //   $obj = new Weddings();
//   require_once (plugin_dir_path( __FILE__ ).'/Weddings.php');

// class Ajaxfilters extends Weddings  {
    
//          function __construct()
//         {
//             //  parent::__construct();
        
            
//         add_action( 'wp_ajax_loading_venue_ajax',array($this,'loading_venue_ajax') );
//         add_action( 'wp_ajax_nopriv_loading_venue_ajax',array($this,'loading_venue_ajax') );
        
            
//         }
        
//         function loading_venue_ajax(){
            
//             echo "working";
        
            
//         }
        
        
        
// }


// $obj = new Ajaxfilters();